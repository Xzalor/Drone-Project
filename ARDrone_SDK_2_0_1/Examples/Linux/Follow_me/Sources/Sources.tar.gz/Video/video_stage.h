#ifndef _IHM_STAGES_O_GTK_H
#define _IHM_STAGES_O_GTK_H

#include <config.h>
#include <VP_Api/vp_api_thread_helper.h>


PROTO_THREAD_ROUTINE(video_stage, data);

#endif // _IHM_STAGES_O_GTK_H
